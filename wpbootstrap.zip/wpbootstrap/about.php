<?php /* Template Name: about */ ?>
<?php get_header(); ?>
<section class="aboutPage">
  <div class="container">
    <h1>KAUNG LWIN</h1>
    <p>Front-End Web Developer, Web Designer</p>
  </div>
</section>
          <?php if(have_posts()) : ?>
            <?php while(have_posts()) : the_post(); ?>
          <div class="blog-post">
            <?php the_content(); ?>
          </div><!-- /.blog-post -->
          <?php endwhile; ?>
        <?php else : ?>
          <p><?php __('No Page Found'); ?></p>
        <?php endif; ?>
    <?php get_footer(); ?>