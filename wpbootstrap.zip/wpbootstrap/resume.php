<?php /* Template Name: resume */ ?>
<?php get_header(); ?>
<section class="resumePage">
    <h1>ALWAYS LEARNING AND IMPROVING</h1>
    <p>Find out what I've done and what I can do for you</p>
</section>
          <?php if(have_posts()) : ?>
            <?php while(have_posts()) : the_post(); ?>
          <div class="blog-post">
            <?php the_content(); ?>
          </div><!-- /.blog-post -->
          <?php endwhile; ?>
        <?php else : ?>
          <p><?php __('No Page Found'); ?></p>
        <?php endif; ?>
<section class="boxes2">
<div style="padding: 0 15%;">
  <h3>Hire a front-end developer today</h3>
  <p>Since you know what I've done and I'm capabale of, feel free to contact me today. I always welcome passionate business owners who want to make their website represents who they are and what they do.</p>
</div>
 <a href="/wordpress/contact/"><button class="custButton">CONTACT ME TODAY</button></a>
</section>
    <?php get_footer(); ?>