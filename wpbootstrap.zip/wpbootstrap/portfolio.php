<?php /* Template Name: portfolio */ ?>
<?php get_header(); ?>
<section class="portfolioPage">
    <h1>MY PORTFOLIO AS A DEVELOPER</h1>
    <p>Here you can view my past works</p>
</section>
          <?php if(have_posts()) : ?>
            <?php while(have_posts()) : the_post(); ?>
          <div class="blog-post">
            <?php the_content(); ?>
          </div><!-- /.blog-post -->
          <?php endwhile; ?>
        <?php else : ?>
          <p><?php __('No Page Found'); ?></p>
        <?php endif; ?>
    <?php get_footer(); ?>